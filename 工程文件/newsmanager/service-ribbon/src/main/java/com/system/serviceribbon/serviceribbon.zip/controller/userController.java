package com.system.serviceribbon.controller;


import com.system.serviceribbon.bean.result;
import com.system.serviceribbon.bean.user;
import com.system.serviceribbon.services.userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/user")
public class userController {
    @Autowired
    private userService userservice;

    /**
     * 登录
     * @param user 参数封装
     * @return Result
     */
    @ResponseBody
    @PostMapping(value = "/login")
    public result login(user user, HttpServletResponse response){
        result login = userservice.login(user);
        response.setHeader("Access-Control-Allow-Origin","*");
        response.setHeader("Cache-Control","no-cache");
        System.out.println(login.getMsg());
        System.out.println(login.getDetail());
        return login;
    }
}
