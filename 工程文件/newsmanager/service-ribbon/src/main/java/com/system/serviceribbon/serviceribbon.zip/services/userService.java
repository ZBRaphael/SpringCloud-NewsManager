package com.system.serviceribbon.services;

import com.system.serviceribbon.bean.result;
import com.system.serviceribbon.bean.user;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.system.serviceribbon.mapper.userMapper;
@Service
public class userService {
    @Autowired
    private userMapper userMapper;

    public result login(user user){
        result res=new result();
        res.setSuccess(false);
        res.setDetail(null);
        try {
            Integer userid = userMapper.login(user);
            if(userid == null){
                res.setMsg("用户名或密码错误");
            }else{
                res.setMsg("登录成功");
                res.setSuccess(true);
                user.setUser_id(userid);
                res.setDetail(user);
            }
        }catch (Exception e){
            res.setMsg(e.getMessage());
            e.printStackTrace();
        }
        return res;
    }
}
